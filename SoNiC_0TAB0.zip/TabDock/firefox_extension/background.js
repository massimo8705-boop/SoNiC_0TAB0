// SoNiC_0TAB0 — une sortie Internet par conteneur Firefox + sessions.
// Aucun repli sur « connexion normale » : si la route est injoignable, la requête échoue (pas de fuite d'IP).
let map = {}, backup = {}, mine = [];
const short = p => shortProxy(p);
const ready = initLang();
// Firefox ne transmet que la réponse du premier écouteur onMessage qui renvoie une promesse : un seul écouteur,
// qui aiguille chaque commande vers le bon gestionnaire.
const cmdHandlers = [];
const onCmd = f => cmdHandlers.push(f);
const CMD_OWNER = { testIp: 0, sessions: 0, save: 0, restore: 0, delete: 0,
                    reloadTab: 1, getAuto: 1, setAuto: 1, keyReload: 1, tile: 2, untile: 2, tileState: 2 };
browser.runtime.onMessage.addListener((msg, sender) => {
  const i = msg && CMD_OWNER[msg.cmd];
  return i === undefined ? undefined : cmdHandlers[i](msg, sender);
});
// actualisation automatique : tabId -> { secs, next, onSwitch }   (en mémoire : propre à cette session de Firefox)
const auto = new Map();
let reloadOnSwitch = false;
browser.storage.local.get("reloadOnSwitch").then(s => { reloadOnSwitch = !!s.reloadOnSwitch; });

async function refresh() {
  const s = await loadState(); map = s.map; backup = s.backup; mine = s.mine;
  await ready; buildMenu(); refreshBadges();
}
refresh();
browser.storage.onChanged.addListener(async ch => {
  if (ch.lang) await initLang();
  if (ch.reloadOnSwitch) reloadOnSwitch = !!ch.reloadOnSwitch.newValue;
  refresh();
});

function notify(message) {
  try { browser.notifications.create({ type: "basic", iconUrl: "icons/icon-96.png", title: "SoNiC_0TAB0", message }); } catch (e) {}
}

// ---- proxy par conteneur ---------------------------------------------------
browser.proxy.onRequest.addListener(details => {
  const raw = (map[details.cookieStoreId] || "").trim();
  if (!raw) return { type: "direct" };
  const main = toProxyInfo(raw);
  if (!main) return [{ type: "http", host: "127.0.0.1", port: 9 }];          // route invalide : on bloque
  const list = [main];
  const sec = toProxyInfo((backup[details.cookieStoreId] || "").trim());      // route de secours (facultative)
  if (sec) list.push(sec);
  list.forEach(i => { i.failoverTimeout = 5; });                              // principale, puis secours ; jamais « direct »
  return list;
}, { urls: ["<all_urls>"] });

let lastWarn = 0;
browser.proxy.onError.addListener(err => {
  const now = Date.now();
  if (now - lastWarn < 60000) return;
  lastWarn = now;
  notify(t("n_route_fail", (err && err.message) || "proxy"));
});

// identifiants des proxys HTTP(S) (les SOCKS les reçoivent directement ci-dessus)
browser.webRequest.onAuthRequired.addListener(details => {
  if (!details.isProxy) return {};
  const d = parseProxy(map[details.cookieStoreId]);
  return d && d.user ? { authCredentials: { username: d.user, password: d.pass || "" } } : {};
}, { urls: ["<all_urls>"] }, ["blocking"]);

// ---- pastille « IP » sur les onglets routés -----------------------------------
browser.browserAction.setBadgeBackgroundColor({ color: "#ffc857" });
if (browser.browserAction.setBadgeTextColor) browser.browserAction.setBadgeTextColor({ color: "#111111" });
function badge(tab) {
  if (!tab) return;
  const p = map[tab.cookieStoreId], bk = backup[tab.cookieStoreId];
  const rl = auto.has(tab.id) ? "⟳" : "";
  browser.browserAction.setBadgeText({ tabId: tab.id, text: (p ? "IP" : "") + rl });
  browser.browserAction.setTitle({ tabId: tab.id,
    title: p ? short(p) + (bk ? "  ↪ " + short(bk) : "") : browser.i18n.getMessage("actionTitle") });
}
async function refreshBadges() { for (const tb of await browser.tabs.query({})) badge(tb); }
browser.tabs.onActivated.addListener(async i => badge(await browser.tabs.get(i.tabId)));
browser.tabs.onUpdated.addListener((id, ch, tab) => badge(tab), { properties: ["status", "url"] });

// ---- clic droit : ouvrir un lien / une page via un conteneur routé ---------------
async function buildMenu() {
  await browser.contextMenus.removeAll();
  let ids = [];
  try { ids = (await browser.contextualIdentities.query({})) || []; } catch (e) {}
  browser.contextMenus.create({ id: "td", title: t("menu_title"), contexts: ["link", "page", "tab"] });
  // clic droit sur un onglet → actualisation automatique
  browser.contextMenus.create({ id: "ar", title: t("menu_autoreload"), contexts: ["tab"] });
  for (const secs of RELOAD_SECS) {
    browser.contextMenus.create({ id: "ar:" + secs, parentId: "ar", type: "radio", checked: secs === 0,
      title: t(secs ? "rl_" + secs : "rl_off"), contexts: ["tab"] });
  }
  browser.contextMenus.create({ id: "ar-sep", parentId: "ar", type: "separator", contexts: ["tab"] });
  browser.contextMenus.create({ id: "ar:switch", parentId: "ar", type: "checkbox", checked: false,
    title: t("menu_every_switch"), contexts: ["tab"] });
  // variation aléatoire (±) : sous-menu de valeurs prêtes, la valeur exacte se règle dans le panneau / les options
  browser.contextMenus.create({ id: "jt", parentId: "ar", title: t("menu_jitter"), contexts: ["tab"] });
  for (const v of JITTER_PRESETS) {
    browser.contextMenus.create({ id: "jt:" + v, parentId: "jt", type: "radio", checked: v === 0,
      title: v ? "± " + v + " %" : t("jitter_none"), contexts: ["tab"] });
  }
  for (const c of ids) {
    const p = map[c.cookieStoreId];
    browser.contextMenus.create({ id: "td:" + c.cookieStoreId, parentId: "td",
      title: c.name + (p ? "   ◈ " + short(p) : "   " + t("menu_normal")), contexts: ["link", "page", "tab"] });
  }
}
// Ouvre une adresse dans un conteneur SANS l'envoyer en fin de barre :
//  - clic droit sur un onglet  -> « rouvrir dans ce conteneur » à la même place (l'original est fermé, comme Firefox)
//  - lien / page               -> juste à droite de l'onglet courant
async function openInContainer(url, cookieStoreId, tab, replace) {
  const o = { url, cookieStoreId, active: true };
  if (tab) {
    o.windowId = tab.windowId;
    o.index = replace ? tab.index : tab.index + 1;
    if (replace && tab.pinned) o.pinned = true;
    if (!replace) o.openerTabId = tab.id;
  }
  let nt;
  try { nt = await browser.tabs.create(o); }
  catch (e) { delete o.openerTabId; try { nt = await browser.tabs.create(o); } catch (e2) { return null; } }
  if (replace && tab && nt) { try { await browser.tabs.remove(tab.id); } catch (e) {} }
  return nt;
}
const JITTER_PRESETS = [0, 5, 10, 25, 50, 100];
// à l'ouverture du menu, les coches reflètent l'état réel de CET onglet
try {
  browser.contextMenus.onShown.addListener(async (info, tab) => {
    if (!tab) return;
    const a = auto.get(tab.id) || { secs: 0, onSwitch: false, jitter: defaultJitter };
    for (const secs of RELOAD_SECS) browser.contextMenus.update("ar:" + secs, { checked: secs === a.secs });
    browser.contextMenus.update("ar:switch", { checked: !!a.onSwitch });
    const near = JITTER_PRESETS.reduce((b, v) => Math.abs(v - a.jitter) < Math.abs(b - a.jitter) ? v : b, 0);
    for (const v of JITTER_PRESETS) browser.contextMenus.update("jt:" + v, { checked: v === near });
    try { browser.contextMenus.refresh(); } catch (e) {}
  });
} catch (e) {}
browser.contextMenus.onClicked.addListener((info, tab) => {
  const id = String(info.menuItemId);
  if (id.startsWith("jt:") && tab) {
    const cur = auto.get(tab.id) || { secs: 0, onSwitch: false };
    const v = parseFloat(id.slice(3));
    if (cur.secs || cur.onSwitch) setAuto(tab.id, cur.secs, cur.onSwitch, v);
    else { defaultJitter = v; browser.storage.local.set({ rlJitter: v }); }   // pas d'auto actif : devient la valeur par défaut
    return;
  }
  if (id.startsWith("ar:") && tab) {
    if (id === "ar:switch") {
      const cur = auto.get(tab.id) || { secs: 0, next: 0, onSwitch: false };
      setAuto(tab.id, cur.secs, !cur.onSwitch);
    } else setAuto(tab.id, parseInt(id.slice(3), 10), (auto.get(tab.id) || {}).onSwitch);
    return;
  }
  if (!id.startsWith("td:")) return;
  const cx = info.contexts || [];
  const fromTab = cx.includes("tab") && !cx.includes("page") && !cx.includes("link");
  const url = info.linkUrl || (tab && tab.url) || info.pageUrl;
  openInContainer(url, id.slice(3), tab, fromTab);
});
for (const ev of ["onCreated", "onRemoved", "onUpdated"]) {
  try { browser.contextualIdentities[ev].addListener(buildMenu); } catch (e) {}
}

// ---- test d'IP réel : onglet invisible DANS le conteneur ------------------------------
async function testIp(cookieStoreId) {
  const create = { url: "https://api.ipify.org/?format=text", active: false };
  if (cookieStoreId && cookieStoreId !== DEFAULT_ID) create.cookieStoreId = cookieStoreId;
  let tab;
  try { tab = await browser.tabs.create(create); }
  catch (e) { return { ok: false, code: "container" }; }
  try {
    await new Promise((resolve, reject) => {
      const to = setTimeout(() => { browser.tabs.onUpdated.removeListener(h); reject(new Error("timeout")); }, 15000);
      function h(id, ch) {
        if (id === tab.id && ch.status === "complete") { clearTimeout(to); browser.tabs.onUpdated.removeListener(h); resolve(); }
      }
      browser.tabs.onUpdated.addListener(h);
    });
    const r = await browser.tabs.executeScript(tab.id, { code: "document.body ? document.body.innerText.trim() : ''" });
    const ip = ((r && r[0]) || "").trim();
    return /^[0-9a-fA-F:.]{3,45}$/.test(ip) ? { ok: true, ip } : { ok: false, code: "unexpected" };
  } catch (e) {
    const m = String((e && e.message) || e);
    return { ok: false, code: m === "timeout" ? "timeout" : "unexpected", detail: m };
  } finally {
    try { await browser.tabs.remove(tab.id); } catch (e) {}
  }
}

// =====================================================================================
// Sessions : onglets + conteneur + route, enregistrés automatiquement
//   last  = dernier état connu · prev = état de la veille (copié au démarrage de Firefox)
//   named = sessions enregistrées à la main
// =====================================================================================
const WEB = /^(https?|ftp):/i;

async function snapshot() {
  let ids = [];
  try { ids = (await browser.contextualIdentities.query({})) || []; } catch (e) {}
  const byId = {}; ids.forEach(c => { byId[c.cookieStoreId] = c; });
  const used = new Set(), windows = [];
  for (const w of await browser.windows.getAll({ populate: true, windowTypes: ["normal"] })) {
    if (w.incognito) continue;
    const tabs = [];
    for (const tb of w.tabs) {
      if (!WEB.test(tb.url || "")) continue;
      const c = byId[tb.cookieStoreId] ? tb.cookieStoreId : null;
      if (c) used.add(c);
      tabs.push({ url: tb.url, title: tb.title || "", pinned: !!tb.pinned, c });
    }
    if (tabs.length) windows.push(tabs);
  }
  const containers = [...used].map(id => ({ id, name: byId[id].name, color: byId[id].color, icon: byId[id].icon,
                                            route: map[id] || "", backup: backup[id] || "" }));
  return { t: Date.now(), containers, windows };
}
const countTabs = s => (s && s.windows ? s.windows.reduce((n, w) => n + w.length, 0) : 0);
const summarize = s => (s ? { t: s.t, count: countTabs(s) } : null);

let autosaveReady = false, timer = null;
setTimeout(() => { autosaveReady = true; scheduleSave(); }, 15000);   // laisse Firefox finir sa propre restauration
function scheduleSave() {
  if (!autosaveReady) return;
  clearTimeout(timer);
  timer = setTimeout(async () => {
    const s = await snapshot();
    if (countTabs(s)) await browser.storage.local.set({ last: s });
  }, 4000);
}
for (const ev of ["onCreated", "onRemoved", "onMoved", "onAttached", "onDetached"]) browser.tabs[ev].addListener(scheduleSave);
browser.tabs.onUpdated.addListener(scheduleSave, { properties: ["url", "pinned"] });
browser.windows.onRemoved.addListener(scheduleSave);

async function restore(sess, onlyMissing) {
  if (!sess || !countTabs(sess)) return 0;
  const existing = (await browser.contextualIdentities.query({})) || [];
  const idMap = {};
  let changed = false;
  for (const c of sess.containers || []) {
    let cur = existing.find(x => x.cookieStoreId === c.id && x.name === c.name) || existing.find(x => x.name === c.name);
    if (!cur) {
      try { cur = await browser.contextualIdentities.create({ name: c.name, color: c.color, icon: c.icon }); existing.push(cur); }
      catch (e) { continue; }
    }
    idMap[c.id] = cur.cookieStoreId;
    if (c.route && !map[cur.cookieStoreId]) { map[cur.cookieStoreId] = c.route; changed = true; }          // on ne touche pas aux routes déjà réglées
    if (c.backup && !backup[cur.cookieStoreId]) { backup[cur.cookieStoreId] = c.backup; changed = true; }
  }
  if (changed) await browser.storage.local.set({ map, backup });

  const have = new Set();
  if (onlyMissing) for (const tb of await browser.tabs.query({})) have.add((tb.cookieStoreId || DEFAULT_ID) + "|" + tb.url);
  let opened = 0;
  const open = async (tab, winId, first) => {
    const cs = tab.c ? idMap[tab.c] : null;
    if (tab.c && !cs) return;
    if (have.has((cs || DEFAULT_ID) + "|" + tab.url)) return;
    const o = { url: tab.url, pinned: tab.pinned, active: first, windowId: winId };
    if (cs) o.cookieStoreId = cs;
    if (!first) { o.discarded = true; if (tab.title) o.title = tab.title; }          // chargés à la demande : léger
    try { await browser.tabs.create(o); opened++; }
    catch (e) { try { delete o.discarded; delete o.title; await browser.tabs.create(o); opened++; } catch (e2) {} }
  };
  if (onlyMissing) {
    const cur = await browser.windows.getLastFocused({ windowTypes: ["normal"] });
    for (const w of sess.windows) for (const tab of w) await open(tab, cur.id, false);
  } else {
    for (const w of sess.windows) {
      const win = await browser.windows.create({});
      const blank = win.tabs && win.tabs[0] && win.tabs[0].id;
      let first = true;
      for (const tab of w) { await open(tab, win.id, first); first = false; }
      if (blank && opened) { try { await browser.tabs.remove(blank); } catch (e) {} }
    }
  }
  scheduleSave();
  return opened;
}

browser.runtime.onStartup.addListener(async () => {
  const st = await browser.storage.local.get(["last", "autoRestore"]);
  if (st.last) await browser.storage.local.set({ prev: st.last });       // avant toute sauvegarde automatique
  setTimeout(async () => {
    const s = await browser.storage.local.get(["prev", "autoRestore"]);
    if (s.autoRestore !== false && s.prev) {
      const n = await restore(s.prev, true);
      if (n) { await ready; notify(t("n_restored", n)); }
    }
  }, 8000);
});

async function namedSave(name) {
  const s = await snapshot();
  const { named } = await browser.storage.local.get("named");
  const all = named || {};
  all[name] = s;
  const keys = Object.keys(all).sort((a, b) => all[b].t - all[a].t).slice(0, 30);   // 30 sessions au plus
  const kept = {}; keys.forEach(k => { kept[k] = all[k]; });
  await browser.storage.local.set({ named: kept });
  return countTabs(s);
}

browser.commands.onCommand.addListener(async cmd => {
  await ready;
  if (cmd === "save-session") {
    const d = new Date(), p = n => String(n).padStart(2, "0");
    const n = await namedSave(`${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`);
    notify(t("n_saved", n));
  } else if (cmd === "test-ip") {
    const [tb] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tb) return;
    let name = "—";
    try { name = (await browser.contextualIdentities.get(tb.cookieStoreId)).name; } catch (e) { name = t("default_container"); }
    const r = await testIp(tb.cookieStoreId);
    notify(r.ok ? t("n_test", name, r.ip) : t("n_test_fail", name, r.code || "?"));
  }
});

onCmd(async msg => {
  if (!msg) return;
  if (msg.cmd === "testIp") return testIp(msg.id);
  if (msg.cmd === "sessions") {
    const s = await browser.storage.local.get(["last", "prev", "named"]);
    const named = Object.entries(s.named || {}).map(([name, v]) => ({ name, t: v.t, count: countTabs(v) }))
                        .sort((a, b) => b.t - a.t);
    return { last: summarize(s.last), prev: summarize(s.prev || s.last), named };
  }
  if (msg.cmd === "save") return namedSave(String(msg.name || "").trim().slice(0, 60) || "session");
  if (msg.cmd === "restore") {
    const s = await browser.storage.local.get(["last", "prev", "named"]);
    const sess = msg.which === "named" ? (s.named || {})[msg.name] : (s.prev || s.last);
    return restore(sess, false);
  }
  if (msg.cmd === "delete") {
    const { named } = await browser.storage.local.get("named");
    if (named) { delete named[msg.name]; await browser.storage.local.set({ named }); }
    return true;
  }
});

// =====================================================================================
// Actualisation : alternative à F5 + actualisation automatique + « à chaque retour sur l'onglet »
// =====================================================================================
const RELOAD_SECS = [0, 15, 30, 60, 120, 300, 600, 1800];

// délai avant la prochaine actualisation : secs ± jitter %, tiré au hasard (jamais moins de 1 s)
function nextDelayMs(secs, jitter) {
  const j = Math.min(100, Math.max(0, +jitter || 0)) / 100;
  const factor = 1 + (Math.random() * 2 - 1) * j;
  return Math.max(1000, Math.round(secs * 1000 * factor));
}
let defaultJitter = 0;
browser.storage.local.get("rlJitter").then(s => { defaultJitter = +s.rlJitter || 0; });
browser.storage.onChanged.addListener(ch => { if (ch.rlJitter) defaultJitter = +ch.rlJitter.newValue || 0; });

function setAuto(tabId, secs, onSwitch, jitter) {
  const old = auto.get(tabId);
  const j = jitter === undefined ? (old ? old.jitter : defaultJitter) : jitter;
  if (!secs && !onSwitch) auto.delete(tabId);
  else auto.set(tabId, { secs, jitter: j, next: Date.now() + (secs ? nextDelayMs(secs, j) : 0), onSwitch: !!onSwitch });
  browser.tabs.get(tabId).then(badge).catch(() => {});
}
async function reloadTab(tabId, hard) {
  try { await browser.tabs.reload(tabId, { bypassCache: !!hard }); return true; } catch (e) { return false; }
}
setInterval(async () => {
  const now = Date.now();
  for (const [id, a] of auto) {
    if (a.secs && now >= a.next) {
      a.next = now + nextDelayMs(a.secs, a.jitter);        // reprogrammé d'abord (avec variation aléatoire) : pas de rafale
      if (!(await reloadTab(id, false))) auto.delete(id);   // onglet fermé
    }
  }
}, 1000);
browser.tabs.onRemoved.addListener(id => auto.delete(id));
browser.tabs.onActivated.addListener(async info => {
  const a = auto.get(info.tabId);
  if (!(reloadOnSwitch || (a && a.onSwitch))) return;
  setTimeout(async () => {                                 // laisse Firefox charger un onglet « endormi » avant de décider
    try {
      const tb = await browser.tabs.get(info.tabId);
      if (tb.active && tb.status !== "loading" && /^(https?|ftp|file):/i.test(tb.url || "")) await reloadTab(info.tabId, false);
    } catch (e) {}
  }, 400);
});
// menu clic droit : coche l'intervalle de l'onglet visé
try {
  browser.menus.onShown.addListener(async (info, tab) => {
    if (!tab || !info.contexts.includes("tab")) return;
    const a = auto.get(tab.id) || { secs: 0, onSwitch: false };
    for (const secs of RELOAD_SECS) { try { await browser.menus.update("ar:" + secs, { checked: secs === a.secs }); } catch (e) {} }
    try { await browser.menus.update("ar:switch", { checked: !!a.onSwitch }); } catch (e) {}
    browser.menus.refresh();
  });
} catch (e) {}

browser.commands.onCommand.addListener(async cmd => {
  if (cmd !== "reload-tab") return;
  const [tb] = await browser.tabs.query({ active: true, currentWindow: true });
  if (tb) reloadTab(tb.id, false);
});
onCmd(async (msg, sender) => {
  if (!msg) return;
  if (msg.cmd === "keyReload") return sender && sender.tab ? reloadTab(sender.tab.id, false) : false;
  if (msg.cmd === "reloadTab") return reloadTab(msg.tabId, msg.hard);
  if (msg.cmd === "getAuto") return auto.get(msg.tabId) || { secs: 0, onSwitch: false, jitter: defaultJitter, next: 0 };
  if (msg.cmd === "setAuto") {
    if (msg.jitter !== undefined) await browser.storage.local.set({ rlJitter: msg.jitter });
    setAuto(msg.tabId, msg.secs, msg.onSwitch, msg.jitter);
    return true;
  }
});

// =====================================================================================
// Vue scindée : jusqu'à 4 onglets rangés côte à côte (une fenêtre par onglet → conteneurs et routes séparés)
// =====================================================================================
let splitState = null;       // { origWin, origBounds, items:[{id,win,index}], winIds:[] }

function tileRects(n, mode, A, gap) {                // même logique que l'application Windows
  const { left, top, width: W, height: H } = A;
  const R = (x, y, w, h) => ({ left: left + x, top: top + y, width: w, height: h });
  if (n <= 1) return [R(0, 0, W, H)];
  if (mode === "main" && n >= 3) {
    const lw = Math.floor((W - gap) * 0.6), rw = W - gap - lw, k = n - 1, rh = Math.floor((H - gap * (k - 1)) / k);
    return [R(0, 0, lw, H)].concat(Array.from({ length: k }, (_, i) => R(lw + gap, i * (rh + gap), rw, rh)));
  }
  const cols = mode === "rows" ? 1 : (mode === "cols" || mode === "main") ? n : (n <= 4 ? 2 : 3);
  const rows = Math.ceil(n / cols), ch = Math.floor((H - gap * (rows - 1)) / rows);
  return Array.from({ length: n }, (_, i) => {
    const r = Math.floor(i / cols), c = i % cols, k = Math.min(cols, n - r * cols), cw = Math.floor((W - gap * (k - 1)) / k);
    return R(c * (cw + gap), r * (ch + gap), cw, ch);
  });
}

async function untile() {
  const st = splitState; splitState = null;
  if (!st) return false;
  for (const it of st.items.slice(1)) {                           // remet chaque onglet dans sa fenêtre d'origine
    try { await browser.tabs.move(it.id, { windowId: it.win, index: it.index }); }
    catch (e) {
      try { await browser.tabs.move(it.id, { windowId: st.origWin, index: -1 }); } catch (e2) {}
    }
  }
  for (const id of st.winIds) { try { await browser.windows.remove(id); } catch (e) {}   // fenêtres restées vides
  }
  try {
    const b = st.origBounds;
    await browser.windows.update(st.origWin, { state: "normal" });
    await browser.windows.update(st.origWin, { left: b.left, top: b.top, width: b.width, height: b.height });
    if (b.state === "maximized" || b.state === "fullscreen") await browser.windows.update(st.origWin, { state: b.state });
  } catch (e) {}
  return true;
}

async function tileTabs(tabIds, mode, area) {
  tabIds = [...new Set(tabIds)].slice(0, 4);
  if (tabIds.length < 2) return false;
  if (splitState) await untile();
  const tabs = [];
  for (const id of tabIds) { try { tabs.push(await browser.tabs.get(id)); } catch (e) {} }
  if (tabs.length < 2) return false;
  const w0 = await browser.windows.get(tabs[0].windowId);
  const st = { origWin: w0.id, origBounds: { left: w0.left, top: w0.top, width: w0.width, height: w0.height, state: w0.state },
               items: tabs.map(tb => ({ id: tb.id, win: tb.windowId, index: tb.index })), winIds: [] };
  const rects = tileRects(tabs.length, mode, area, 0);
  splitState = st;
  try {
    await browser.windows.update(w0.id, { state: "normal" });
    await browser.windows.update(w0.id, rects[0]);
    await browser.tabs.update(tabs[0].id, { active: true });
    for (let i = 1; i < tabs.length; i++) {
      const nw = await browser.windows.create(Object.assign({ tabId: tabs[i].id }, rects[i]));
      st.winIds.push(nw.id);
    }
    return true;
  } catch (e) {
    await untile();
    return false;
  }
}
browser.windows.onRemoved.addListener(id => {                      // la fenêtre d'origine est fermée : plus rien à rétablir
  if (splitState && splitState.origWin === id) splitState = null;
});
onCmd(async msg => {
  if (!msg) return;
  if (msg.cmd === "tile") return tileTabs(msg.tabIds, msg.mode, msg.area);
  if (msg.cmd === "untile") return untile();
  if (msg.cmd === "tileState") return !!splitState;
});
