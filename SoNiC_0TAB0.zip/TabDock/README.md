# SoNiC_0TAB0 1.6

Une fenêtre, des onglets qui sont de vraies fenêtres de Firefox / Chrome / Opera / Edge / Brave…,
groupes colorés par glisser-déposer, **affichage côte à côte**, sessions, **une sortie Internet par onglet**.

## Installer
1. **Extraire tout** le zip (clic droit → « Extraire tout… »), ne rien lancer depuis l'intérieur du zip.
2. Double-cliquez **`INSTALLER.cmd`** (il détecte Python et propose de l'installer si besoin).
   Erreurs : boîte de dialogue + `%TEMP%\sonic_0tab0_install.log`.
3. Sans installer : `SoNiC_0TAB0.cmd`.

Démarrage avec Windows : « user » ou « admin » (tâche planifiée, sans invite UAC). SoNiC_0TAB0 s'ouvre
au premier plan et restaure la dernière session.

## Utiliser
* **＋** (à droite des onglets) : capturer une fenêtre déjà ouverte, ou lancer un navigateur isolé. **☰** : menu.
* Ctrl+Alt+G sur n'importe quelle fenêtre = la capturer.
* Glisser un onglet SUR un autre = groupe ; bords = réorganiser ; vide à droite = sortir du groupe ;
  **le lâcher sous la barre (ou hors fenêtre) = le détacher à cet endroit**.
* **Ctrl+1 … Ctrl+9** : aller à l'onglet 1…9 (actif quand SoNiC_0TAB0 est au premier plan, y compris
  quand un navigateur intégré a le focus). **Ctrl+Alt+1…9** : idem depuis n'importe où. Ctrl+Tab / Ctrl+Maj+Tab : suivant / précédent.
* Clic milieu = fermer, double-clic = renommer, molette = changer d'onglet.
* **Côte à côte** : clic droit sur l'étiquette d'un groupe → Affichage → colonnes / lignes / grille.
* Clic droit onglet : renommer, groupe, couleur, **Détacher**, fermer.
* Secours : ☰ → Options → « Libérer toutes les fenêtres ».

## Une IP différente par onglet
1. ☰ → Réseau → **Mes connexions Internet** → *Détecter* : chaque carte réseau est testée et son IP publique
   affichée. **Deux cartes avec la même IP = même accès Internet** (ex. Wi-Fi + Ethernet de la même box).
   Pour une 2e IP : une carte Wi-Fi ne rejoint qu'**un seul** réseau (box OU hotspot du téléphone). Branchez le
   téléphone en USB → Paramètres → Connexions → Point d'accès mobile et modem → **Modem USB** : une 2e carte apparaît.
   (ou une clé Wi-Fi USB, ou un VPN).
2. *Créer les routes* : une route (proxy local 127.0.0.1) par IP différente. Si la carte tombe, la connexion
   est refusée (aucun repli silencieux).
3. ＋ → Nouveau navigateur : choisissez profil (cookies séparés) + route.
4. Opera + VPN : profil SoNiC_0TAB0, route vide, activez le VPN d'Opera dans ce profil.
5. Options : rotation d'IP (Tor ou pool), détection de fuite, WebRTC bloqué.

Adresse à saisir dans « proxy » : `socks5://127.0.0.1:10810` (127.0.0.1 = ce PC, 10810 = port de la route ;
choisissez plutôt « Route · … » dans la liste, l'adresse se remplit seule).

## Extension Firefox (autonome)
L'extension fonctionne **seule** (ses propres routes : SOCKS5/HTTP, identifiants, Tor, import/export) ; elle
ajoute en plus les routes de l'application si celle-ci est lancée (désactivable). Voir `firefox_extension/`.

## Installer l'extension : plusieurs IP dans UNE fenêtre Firefox
☰ → Réseau → Extension Firefox : essai temporaire ou installation définitive (signature Mozilla gratuite).
Bouton SoNiC_0TAB0 dans la barre Firefox : route par conteneur, **Tester** (affiche l'IP réelle, signale les
conteneurs qui ont la même IP), Ouvrir, nouveau conteneur routé. Clic droit sur un lien : ouvrir avec une route.

## Dépannage
* Journal : `%APPDATA%\SoNiC_0TAB0\sonic_0tab0.log`.
* Une fenêtre refuse l'intégration : message précis (administrateur ? application protégée ?).
* Ne tuez pas SoNiC_0TAB0 depuis le gestionnaire des tâches : fermez-le par sa croix (les fenêtres sont rendues).

## Thème
Images dans `%APPDATA%\SoNiC_0TAB0\theme` (voir `prepare_theme.py`, `PROMPTS_IMAGES.md`).

## Route de secours (v1.5)
Connexions Internet → sélectionnez une carte → **↪ Route de secours** : si la route tombe, les connexions passent
par l'autre route (notification), puis reviennent seules sur la principale. Jamais de repli sur la connexion normale.
L'IP vue par les sites change pendant la bascule. Extension (v2.1) : « secours » par conteneur dans les réglages.

## Extension v2.2
Anglais / français (sélecteur), icône d'onglet des réglages, panneau compact sans défilement horizontal,
**sessions** (onglets + conteneurs + routes sauvegardés automatiquement, restauration au démarrage, sessions nommées),
raccourcis Alt+Maj+S (enregistrer) / Alt+Maj+I (tester l'IP du conteneur actif), alerte « IP identique à la connexion normale ».

## Actualisation des onglets (application 1.6 / extension 2.3)
* **Application** : clic droit sur un onglet → *Actualiser (F5)*, *Actualiser sans cache (Ctrl+F5)*, *Actualisation automatique*
  (15 s … 30 min, ou « à chaque sélection de l'onglet »). Menu Options → *Actualiser l'onglet actif* et
  *Actualiser un onglet à chaque changement d'onglet* (option globale). Raccourci **Ctrl+Alt+F5**. Un ⟳ s'affiche sur les onglets concernés.
  La touche n'est envoyée que si SoNiC_0TAB0 est au premier plan et que Ctrl/Alt sont relâchées ; réglages enregistrés dans les sessions.
* **Extension** : bouton *Actualiser* / *sans cache* dans le panneau, actualisation automatique par onglet, clic droit sur l'onglet →
  « SoNiC_0TAB0 : actualisation auto », raccourci **Alt+Maj+R**, option globale « à chaque fois que je sélectionne un onglet ».
  Une actualisation peut faire perdre un texte en cours de saisie.

## Extension v2.4
« Ouvrir avec une route » : un clic droit sur un onglet le rouvre dans le conteneur **à la même place** (l'original est fermé, comme
« Rouvrir dans un conteneur » de Firefox) ; un lien ou une page s'ouvre **juste à droite** de l'onglet courant, plus en fin de barre.
Le bouton « Ouvrir » du panneau fait de même. Nouvel identifiant d'extension (`sonic-0tab0@sonic-0tab0.invalid`) et nouvelle adresse du projet.

## Vue scindée jusqu'à 4 (application 1.7 / extension 2.5)
* **Application** : menu ☰ → *Vue scindée (2 à 4 onglets)…*, clic droit sur un onglet → *Vue scindée avec d'autres onglets…*, ou **Ctrl+Alt+V**.
  Cochez 2 à 4 onglets (navigateurs différents possibles), choisissez *côte à côte*, *empilés*, *grille 2 × 2* ou *un grand + les autres*
  (aperçu en direct). Les onglets sont regroupés et affichés ensemble ; *Désactiver la vue scindée* revient à un seul onglet.
* **Extension** : panneau → *Vue scindée* : coche 2 à 4 onglets de la fenêtre, disposition au choix, *Scinder* range une fenêtre par onglet
  (chaque conteneur et sa route restent séparés), *Rétablir* remet tout en place. La vue scindée native de Firefox (2 onglets, un seul conteneur)
  reste disponible ; Firefox ne propose aucune API d'extension pour la piloter, d'où ce rangement par fenêtres.

## Extension v2.6
* Correctif : le panneau affichait toujours « désactivée » et ne retrouvait pas l'état de l'onglet (Firefox ne transmet que la réponse du
  premier écouteur de messages ; il n'y en a plus qu'un).
* **± variation aléatoire** de l'actualisation automatique : case « ± », jauge (échelle logarithmique) ou saisie de 0,01 % à 100 %.
  Exemple : 1 min ± 25 % → chaque actualisation tombe au hasard entre 45 s et 1 min 15 s. La dernière valeur est mémorisée.
  Le panneau affiche la plage et le temps avant la prochaine actualisation.

## Extension v2.7 — raccourcis d'actualisation
Deux raccourcis qui font comme « clic droit sur l'onglet → Actualiser (F5) », modifiables dans Réglages → *Raccourcis d'actualisation* :
1. **`=`** par défaut, sur les pages web ; ignoré quand vous tapez dans un champ de texte (une combinaison avec Ctrl/Alt reste active partout).
2. **Alt+Maj+R** par défaut, commande native de Firefox : marche aussi sur les pages internes ; Firefox exige Ctrl, Alt ou F1–F12.
Cliquez dans le champ puis appuyez sur la combinaison voulue ; boutons *Par défaut* et *Aucun*.

## Application 1.8 / extension 2.8
* **Glisser une fenêtre dans SoNiC_0TAB0** : attrapez la barre de titre d'un navigateur (ou de toute fenêtre) et déposez-la au-dessus de
  SoNiC_0TAB0 : un voile « Relâchez ici pour intégrer » s'affiche, puis la fenêtre devient un onglet (plus besoin de ＋). Désactivable
  dans Paramètres → Général.
* **Sortir un onglet** : glissez-le hors de la barre (en dessous, au-dessus ou sur le côté) : une étiquette suit la souris
  (« Relâcher pour détacher ») ; la fenêtre est posée à l'endroit du relâchement, toujours visible à l'écran.
* L'écran d'accueil « Aucun onglet… » est lisible (texte sur un panneau sombre, image masquée si la fenêtre est petite).
* **± variation aléatoire** aussi dans l'application : clic droit sur un onglet → Actualisation automatique → *± Variation aléatoire…*
  (case, jauge logarithmique, saisie 0,01 à 100 %). Dans l'extension : panneau → Actualiser / actualisation auto → case « ± », et valeur par défaut dans Réglages → Actualisation.
* **Démarrage automatique** : Paramètres → Général → *Vérifier le démarrage* / *Tout supprimer* (registre, dossier Démarrage, tâches planifiées, anciennes
  entrées TabDock). Choisir « Non » nettoie désormais toutes ces sources. L'installateur conserve votre choix à la réinstallation
  (avant, il remettait « Oui » à chaque mise à jour) ; première installation : « Ne pas lancer ».

## Version 3.0 de l'extension — choisir l'IP d'un onglet
- Clic droit sur un onglet → « SoNiC_0TAB0 : connexion (IP) de cet onglet » : liste « Connexion normale », vos routes et celles de l'application (Wi-Fi, 4G du téléphone…). L'onglet est rouvert à la même place dans un conteneur « SoNiC · <route> » créé automatiquement (un conteneur = des cookies séparés).
- Deux onglets côte à côte avec deux IP : choisissez une route différente pour chacun, puis « Vue scindée ».
- Options : état de la détection de l'application + bouton Actualiser, relecture automatique ; l'application utilise un autre port (10801–10809) si 10800 est pris.
- « Désactivée » dans le menu d'actualisation coupe aussi « à chaque retour sur l'onglet ».
