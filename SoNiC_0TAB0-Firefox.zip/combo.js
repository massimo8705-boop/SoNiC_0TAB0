// Combinaisons de touches (partagé : script de page + page de réglages). Format : "Ctrl+Alt+Shift+Meta+Touche", ex. "=", "Alt+Shift+R".
const COMBO_KEYS = { " ": "Space", ArrowUp: "Up", ArrowDown: "Down", ArrowLeft: "Left", ArrowRight: "Right", Escape: "Esc" };
function comboFromEvent(e) {
  const k = e.key;
  if (!k || ["Control", "Shift", "Alt", "Meta", "AltGraph", "OS", "Dead", "Unidentified"].includes(k)) return null;
  const mods = [];
  if (e.ctrlKey) mods.push("Ctrl");
  if (e.altKey) mods.push("Alt");
  if (e.shiftKey) mods.push("Shift");
  if (e.metaKey) mods.push("Meta");
  const key = COMBO_KEYS[k] || (k.length === 1 ? k.toUpperCase() : k);
  return mods.concat(key).join("+");
}
// Firefox n'accepte nativement que : (Ctrl|Alt|Command|MacCtrl) + touche, ou une touche de fonction.
// Retourne la forme acceptée par browser.commands.update, ou null si la combinaison est impossible.
function nativeCombo(c) {
  if (!c) return "";
  const i = c.lastIndexOf("+", c.length - 2);                 // « Shift++ » : la touche est « + »
  const mods = i < 0 ? [] : c.slice(0, i).split("+");
  let key = i < 0 ? c : c.slice(i + 1);
  key = key === "," ? "Comma" : key === "." ? "Period" : key;
  const valid = /^([A-Z0-9]|F([1-9]|1[0-2])|Space|Up|Down|Left|Right|Home|End|PageUp|PageDown|Insert|Delete|Comma|Period)$/.test(key);
  const isF = /^F([1-9]|1[0-2])$/.test(key);
  const hasMod = mods.includes("Ctrl") || mods.includes("Alt") || mods.includes("Meta");
  if (!valid || !(hasMod || isF)) return null;
  return mods.map(m => (m === "Meta" ? "Command" : m)).concat(key).join("+");
}
