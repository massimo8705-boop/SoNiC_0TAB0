// SoNiC_0TAB0 — raccourci « actualiser l'onglet » (script de page, ne fait rien d'autre).
// Ignoré pendant la saisie dans un champ de texte quand la touche est seule (ex. « = »).
(function () {
  let bind1 = "=";
  const load = () => browser.storage.local.get("reloadKey1").then(s => {
    if (s.reloadKey1 !== undefined) bind1 = s.reloadKey1;
  }).catch(() => {});
  load();
  browser.storage.onChanged.addListener(ch => { if (ch.reloadKey1) load(); });

  function typing(el) {
    let n = el;
    while (n && n.shadowRoot && n.shadowRoot.activeElement) n = n.shadowRoot.activeElement;
    n = n || document.activeElement;
    if (!n || n === document.body) return false;
    const tag = (n.tagName || "").toUpperCase();
    if (tag === "TEXTAREA" || tag === "SELECT") return true;
    if (tag === "INPUT") return !/^(checkbox|radio|button|submit|reset|range|color|image|file)$/i.test(n.type || "text");
    return !!n.isContentEditable || /^(textbox|searchbox|combobox)$/.test(n.getAttribute && n.getAttribute("role") || "");
  }
  window.addEventListener("keydown", e => {
    if (e.repeat || e.isComposing || e.defaultPrevented) return;
    const c = comboFromEvent(e);
    if (!c || !bind1 || c !== bind1) return;       // le raccourci 2 est une commande native de Firefox
    const plain = !(e.ctrlKey || e.altKey || e.metaKey);
    if (plain && typing(e.target)) return;                  // on tape du texte : on ne touche à rien
    e.preventDefault();
    browser.runtime.sendMessage({ cmd: "keyReload" }).catch(() => {});
  }, true);
})();
