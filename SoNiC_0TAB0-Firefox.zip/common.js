// Fonctions partagées (fond, popup, options). Aucune dépendance externe.
const DEFAULT_ID = "firefox-default";
const APP_API = "http://127.0.0.1:10800/routes.json";   // application SoNiC_0TAB0 (facultative)
const PRESETS = [
  { name: "Tor (service)", proxy: "socks5://127.0.0.1:9050" },
  { name: "Tor Browser", proxy: "socks5://127.0.0.1:9150" },
  { name: "Proxy local HTTP", proxy: "http://127.0.0.1:8080" },
];

// "user:pass@host:port", "socks5://host:1080", "http://host:3128"… -> objet, ou null si invalide
function parseProxy(p) {
  p = (p || "").trim();
  if (!p) return null;
  if (!p.includes("://")) p = "http://" + p;
  let u;
  try { u = new URL(p); } catch (e) { return null; }
  if (!u.hostname) return null;
  const scheme = u.protocol.replace(":", "").toLowerCase();
  const type = scheme === "socks4" ? "socks4" : scheme.startsWith("socks") ? "socks" : scheme === "https" ? "https" : "http";
  const def = type.startsWith("socks") ? 1080 : type === "https" ? 443 : 8080;
  return { type, host: u.hostname, port: parseInt(u.port, 10) || def,
           user: u.username ? decodeURIComponent(u.username) : null,
           pass: u.password ? decodeURIComponent(u.password) : null };
}
// version affichable, sans mot de passe
function shortProxy(p) {
  const d = parseProxy(p);
  return d ? `${d.type === "socks" ? "socks5" : d.type}://${d.host}:${d.port}` : String(p || "");
}

async function loadState() {
  const st = await browser.storage.local.get(["map", "backup", "mine", "custom", "detectApp"]);
  let mine = st.mine || [];
  if (!st.mine && Array.isArray(st.custom)) {                 // migration de l'ancienne liste
    mine = st.custom.map(p => ({ name: shortProxy(p), proxy: p }));
  }
  return { map: st.map || {}, backup: st.backup || {}, mine, detectApp: st.detectApp !== false };
}
async function saveState(s) {
  await browser.storage.local.set({ map: s.map, backup: s.backup || {}, mine: s.mine, detectApp: s.detectApp });
}
// l'application écoute sur 10800 (ou 10801…10809 si ce port est pris) ; null = application introuvable
async function fetchAppRoutes() {
  for (let i = 0; i < 10; i++) {
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 1500);
    try {
      const r = await fetch(APP_API.replace(":10800", ":" + (10800 + i)), { cache: "no-store", signal: ctl.signal });
      const j = await r.json();
      clearTimeout(to);
      if (j && j.app === "SoNiC_0TAB0") return j.routes || [];
    } catch (e) { clearTimeout(to); }
  }
  return null;
}

// objet « proxy » attendu par Firefox ; null si l'adresse est invalide
function toProxyInfo(raw) {
  const d = parseProxy(raw);
  if (!d) return null;
  const info = { type: d.type, host: d.host, port: d.port, proxyDNS: d.type.startsWith("socks") };
  if (d.type.startsWith("socks") && d.user) { info.username = d.user; info.password = d.pass || ""; }
  return info;
}
